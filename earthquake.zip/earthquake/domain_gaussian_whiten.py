"""Gaussianized-whitening domain transform for the Tucker density pipeline.

This transform is meant to replace the PIT/KDE domain transform.
It tries to make the transformed density easier for a coordinate-based Tucker
model by doing three things:

1. Per-coordinate normal-score transform:
       x_j -> z_j.
   This is a monotone empirical transform that sends each marginal to an
   approximately standard normal scale.

2. Whitening/rotation:
       z -> y = (z - mean) W^T.
   This removes the main linear dependence and aligns the data with the axes.

3. Robust affine box transform:
       y -> u in [0, 1]^d.
   Tucker basis functions are evaluated on this final [0,1]^d scale.

For density prediction, if p_U(u) is the fitted Tucker density in transformed
space, then

    p_X(x) = p_U(T(x)) * |det DT(x)|.

The Jacobian is computed from the piecewise-linear normal-score transform, the
whitening determinant, and the affine box determinant. No Gaussian KDE marginal
correction is used.
"""

from __future__ import annotations

import numpy as np
from scipy.special import ndtri


class GaussianWhitenBoxDomain:
    """Normal-score + whitening + robust affine box transform.

    Parameters
    ----------
    dim : int
        Data dimension.
    X_train : ndarray, shape (N, dim)
        Training data on the original scale.
    box_quantile_eps : float
        Quantile level used to define the robust box in whitened coordinates.
        For example, 1e-3 uses the 0.1% and 99.9% quantiles.
    box_pad_fraction : float
        Extra padding added to each side of the robust box. A value like 0.05
        adds 5% of the coordinate range on each side.
    ridge : float
        Ridge added to covariance eigenvalues before whitening.
    clip_eps : float
        Final clipping of u values into [clip_eps, 1 - clip_eps].
    derivative_floor : float
        Lower bound for one-dimensional dz/dx slopes in the Jacobian.
    """

    def __init__(
        self,
        dim,
        X_train,
        box_quantile_eps=1e-3,
        box_pad_fraction=0.05,
        ridge=1e-6,
        clip_eps=1e-6,
        derivative_floor=1e-12,
    ):
        X = np.asarray(X_train, dtype=float)
        if X.ndim != 2 or X.shape[1] != dim:
            raise ValueError(f"X_train must have shape (N, {dim}); got {X.shape}")
        if X.shape[0] < 3:
            raise ValueError("X_train must contain at least three observations.")

        self.dim = int(dim)
        self.N_train = X.shape[0]
        self.box_quantile_eps = float(box_quantile_eps)
        self.box_pad_fraction = float(box_pad_fraction)
        self.ridge = float(ridge)
        self.clip_eps = float(clip_eps)
        self.derivative_floor = float(derivative_floor)

        if not (0.0 <= self.box_quantile_eps < 0.5):
            raise ValueError("box_quantile_eps must be in [0, 0.5).")
        if self.box_pad_fraction < 0.0:
            raise ValueError("box_pad_fraction must be nonnegative.")
        if self.ridge < 0.0:
            raise ValueError("ridge must be nonnegative.")
        if not (0.0 <= self.clip_eps < 0.5):
            raise ValueError("clip_eps must be in [0, 0.5).")

        self._fit_marginal_normal_scores(X)

        Z = self._x_to_z(X)
        self.z_mean = Z.mean(axis=0)
        Zc = Z - self.z_mean

        cov = np.cov(Zc, rowvar=False, bias=False)
        cov = np.atleast_2d(cov)
        cov = 0.5 * (cov + cov.T)

        eigvals, eigvecs = np.linalg.eigh(cov)
        eigvals = np.maximum(eigvals, 0.0)
        eigvals_r = eigvals + self.ridge

        self.eigvals = eigvals
        self.eigvecs = eigvecs
        self.whiten = eigvecs @ np.diag(1.0 / np.sqrt(eigvals_r)) @ eigvecs.T
        self.unwhiten = eigvecs @ np.diag(np.sqrt(eigvals_r)) @ eigvecs.T

        sign_w, logdet_w = np.linalg.slogdet(self.whiten)
        if sign_w == 0:
            raise ValueError("Whitening matrix is singular.")
        self.log_abs_det_whiten = float(logdet_w)

        Y = Zc @ self.whiten.T
        qlo = np.quantile(Y, self.box_quantile_eps, axis=0)
        qhi = np.quantile(Y, 1.0 - self.box_quantile_eps, axis=0)
        width = qhi - qlo
        width = np.maximum(width, 1e-12)

        self.box_lower = qlo - self.box_pad_fraction * width
        self.box_upper = qhi + self.box_pad_fraction * width
        self.box_width = np.maximum(self.box_upper - self.box_lower, 1e-12)
        self.log_abs_det_box = -float(np.sum(np.log(self.box_width)))

    # ------------------------------------------------------------------
    # Fitting and one-dimensional monotone normal-score maps
    # ------------------------------------------------------------------

    def _fit_marginal_normal_scores(self, X):
        self.x_grid = []
        self.z_grid = []
        self.slope_grid = []

        # Normal scores. Clipping avoids infinite values.
        ranks = (np.arange(self.N_train) + 0.5) / self.N_train
        eps_rank = 0.5 / self.N_train
        ranks = np.clip(ranks, eps_rank, 1.0 - eps_rank)
        z_scores_full = ndtri(ranks)

        for j in range(self.dim):
            x_sorted = np.sort(X[:, j])

            # Collapse duplicates. For duplicate x's, use the average normal score.
            uniq, inv, counts = np.unique(x_sorted, return_inverse=True, return_counts=True)
            if uniq.size < 2:
                raise ValueError(
                    f"Coordinate {j} has fewer than two unique values; "
                    "normal-score transform is not defined."
                )

            z_sum = np.zeros_like(uniq, dtype=float)
            np.add.at(z_sum, inv, z_scores_full)
            z_unique = z_sum / counts

            dx = np.diff(uniq)
            dz = np.diff(z_unique)
            slopes = dz / np.maximum(dx, 1e-300)
            slopes = np.maximum(slopes, self.derivative_floor)

            self.x_grid.append(uniq.astype(float))
            self.z_grid.append(z_unique.astype(float))
            self.slope_grid.append(slopes.astype(float))

    def _x_to_z(self, X):
        X = np.asarray(X, dtype=float)
        Z = np.empty_like(X, dtype=float)
        for j in range(self.dim):
            Z[:, j] = np.interp(
                X[:, j],
                self.x_grid[j],
                self.z_grid[j],
                left=self.z_grid[j][0],
                right=self.z_grid[j][-1],
            )
        return Z

    def _z_to_x(self, Z):
        Z = np.asarray(Z, dtype=float)
        X = np.empty_like(Z, dtype=float)
        for j in range(self.dim):
            X[:, j] = np.interp(
                Z[:, j],
                self.z_grid[j],
                self.x_grid[j],
                left=self.x_grid[j][0],
                right=self.x_grid[j][-1],
            )
        return X

    def _dzdx(self, X):
        X = np.asarray(X, dtype=float)
        D = np.empty_like(X, dtype=float)
        for j in range(self.dim):
            xg = self.x_grid[j]
            slopes = self.slope_grid[j]

            idx = np.searchsorted(xg, X[:, j], side="right") - 1
            idx = np.clip(idx, 0, len(slopes) - 1)
            D[:, j] = slopes[idx]

        return np.maximum(D, self.derivative_floor)

    # ------------------------------------------------------------------
    # Public API used by the Tucker class
    # ------------------------------------------------------------------

    def transform_data(self, XX):
        """Map original data-space points to [0,1]^d."""
        XX = np.asarray(XX, dtype=float)
        if XX.ndim != 2 or XX.shape[1] != self.dim:
            raise ValueError(f"XX must have shape (N, {self.dim}); got {XX.shape}")

        Z = self._x_to_z(XX)
        Y = (Z - self.z_mean) @ self.whiten.T
        U = (Y - self.box_lower) / self.box_width
        return np.clip(U, self.clip_eps, 1.0 - self.clip_eps)

    def inverse_compute_data(self, UU):
        """Map [0,1]^d points back to original data space."""
        UU = np.asarray(UU, dtype=float)
        if UU.ndim != 2 or UU.shape[1] != self.dim:
            raise ValueError(f"UU must have shape (N, {self.dim}); got {UU.shape}")

        U = np.clip(UU, 0.0, 1.0)
        Y = U * self.box_width + self.box_lower
        Z = Y @ self.unwhiten.T + self.z_mean
        return self._z_to_x(Z)

    def log_abs_det_jacobian(self, X_data_space):
        """Compute log |det dT(x)/dx| for T: x -> u."""
        X = np.asarray(X_data_space, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.dim:
            raise ValueError(f"X_data_space must have shape (N, {self.dim}); got {X.shape}")

        dzdx = self._dzdx(X)
        return (
            np.sum(np.log(dzdx), axis=1)
            + self.log_abs_det_whiten
            + self.log_abs_det_box
        )

    def jacobian_factor(self, X_data_space):
        """Compute |det dT(x)/dx| for T: x -> u."""
        log_jac = self.log_abs_det_jacobian(X_data_space)
        return np.exp(np.clip(log_jac, -745.0, 700.0))

    def transform_density_val(self, val, X_test_data_space=None):
        """Convert density values from transformed space to original data space."""
        val = np.asarray(val, dtype=float).reshape(-1)
        if X_test_data_space is None:
            return val

        X = np.asarray(X_test_data_space, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.dim:
            raise ValueError(f"X_test_data_space must have shape (N, {self.dim}); got {X.shape}")
        if X.shape[0] != val.shape[0]:
            raise ValueError("val and X_test_data_space must have the same length.")

        return val * self.jacobian_factor(X)


# Backward-compatible name if you prefer shorter imports.
GaussianWhitenDomain = GaussianWhitenBoxDomain
