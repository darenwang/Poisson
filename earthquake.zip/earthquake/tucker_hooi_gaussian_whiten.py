"""Tucker density estimator with implicit HOOI and Gaussianized whitening domain.

Drop this file next to:
    local_basis.py
    sampling_local.py
    domain_gaussian_whiten.py

This version removes the PIT/KDE transform. The domain transform is:

    x -> normal scores -> whitening/rotation -> robust affine map to [0,1]^d.

The goal is to make the transformed density more axis-aligned and easier for a
Tucker estimator to approximate.

Important notation:
    N = number of training samples, X_train.shape[0]
    n = number of basis functions per coordinate

For dim=6 and N around 5400, start with n=25 to 50, not n=5400.
"""

from __future__ import annotations

import numpy as np
from scipy.linalg import eigh

from local_basis import generate_basis_mat, polynomial
from sampling_local import Legendre_Sampler
from domain_gaussian_whiten import GaussianWhitenBoxDomain


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------


def estimate_tensor_memory_gb(shape, dtype=np.float64):
    """Estimate memory needed to store an array with the given shape."""
    numel = int(np.prod(shape))
    return numel * np.dtype(dtype).itemsize / (1024 ** 3)


def choose_rank_from_singular_values(
    singular_values,
    threshold=0.9999,
    rank_rule="energy",
    min_rank=1,
):
    """Choose Tucker rank from singular values."""
    s = np.asarray(singular_values, dtype=float)
    if s.size == 0:
        return 0

    if rank_rule == "energy":
        energy = s ** 2
        total_energy = np.sum(energy)
        if total_energy <= 0:
            rank = min_rank
        else:
            cumulative_energy = np.cumsum(energy) / total_energy
            rank = np.searchsorted(cumulative_energy, threshold) + 1
    elif rank_rule == "relative":
        rank = min_rank if s[0] <= 0 else np.sum(s >= threshold * s[0])
    elif rank_rule == "absolute":
        rank = np.sum(s >= threshold)
    elif rank_rule == "eigen_absolute":
        rank = np.sum(s ** 2 >= threshold)
    elif rank_rule == "fixed":
        rank = int(threshold)
    else:
        raise ValueError(
            "Unknown rank_rule. Use one of 'energy', 'relative', 'absolute', "
            "'eigen_absolute', or 'fixed'."
        )

    rank = int(rank)
    rank = max(rank, int(min_rank))
    rank = min(rank, len(s))
    return rank


def _descending_eigh(G):
    """Eigen-decomposition of a symmetric matrix, sorted descending."""
    G = 0.5 * (G + G.T)
    eigvals, eigvecs = eigh(G, check_finite=False)
    idx = np.argsort(eigvals)[::-1]
    return eigvals[idx], eigvecs[:, idx]


def _validate_basis_mat(basis_mat):
    """Convert basis_mat to a list of arrays with shape (N, n)."""
    basis_mat = [np.asarray(B, dtype=float) for B in basis_mat]

    if len(basis_mat) == 0:
        raise ValueError("basis_mat must contain at least one mode.")

    N, n = basis_mat[0].shape
    for j, B in enumerate(basis_mat):
        if B.ndim != 2:
            raise ValueError(f"basis_mat[{j}] must be 2D.")
        if B.shape != (N, n):
            raise ValueError("All basis matrices must have the same shape (N, n).")

    return basis_mat, N, n, len(basis_mat)


def _pairwise_memory_check(N, max_pairwise_memory_gb):
    memory_gb = estimate_tensor_memory_gb((N, N))
    if memory_gb > max_pairwise_memory_gb:
        raise MemoryError(
            f"An N by N pairwise matrix needs about {memory_gb:.2f} GB, "
            f"which exceeds max_pairwise_memory_gb={max_pairwise_memory_gb}."
        )


# -----------------------------------------------------------------------------
# Basis integration and normalization
# -----------------------------------------------------------------------------


def compute_basis_integral(poly_obj, n, quad_order=None):
    """Numerically compute int_0^1 phi_l(x) dx for l=0,...,n-1."""
    n = int(n)
    if quad_order is None:
        quad_order = max(200, 4 * n)
    quad_order = int(quad_order)

    nodes, weights = np.polynomial.legendre.leggauss(quad_order)
    x = 0.5 * (nodes + 1.0)
    w = 0.5 * weights

    vals = np.empty((quad_order, n), dtype=float)
    for i, xx in enumerate(x):
        vals[i, :] = np.asarray(poly_obj.scalar_all_basis_alpha(float(xx)), dtype=float)

    return w @ vals


def compute_constant_coeff(poly_obj, n, quad_order=None):
    """Find coefficients c so that sum_l c_l phi_l(x) approximates 1."""
    n = int(n)
    if quad_order is None:
        quad_order = max(200, 4 * n)
    quad_order = int(quad_order)

    nodes, _ = np.polynomial.legendre.leggauss(quad_order)
    x = 0.5 * (nodes + 1.0)

    V = np.empty((quad_order, n), dtype=float)
    for i, xx in enumerate(x):
        V[i, :] = np.asarray(poly_obj.scalar_all_basis_alpha(float(xx)), dtype=float)

    c, *_ = np.linalg.lstsq(V, np.ones(quad_order), rcond=None)
    return c


def projected_core_mass(core, mat_list, basis_integral):
    """Compute integral of the Tucker density over [0,1]^d."""
    tmp = np.asarray(core, dtype=float)
    for Uj in mat_list:
        v = np.asarray(basis_integral, dtype=float) @ Uj
        tmp = np.tensordot(tmp, v, axes=([0], [0]))
    return float(np.asarray(tmp))


def renormalize_core(core, mat_list, basis_integral, min_abs_mass=1e-14):
    """Scale the Tucker core so that the represented density integrates to one."""
    mass = projected_core_mass(core, mat_list, basis_integral)
    if not np.isfinite(mass) or abs(mass) < min_abs_mass:
        raise ValueError(
            f"Cannot renormalize core because its mass is {mass}. "
            "Try larger ranks or uniform_mixture > 0."
        )
    return core / mass, mass


def outer_from_vectors(vecs):
    """Build an outer product tensor from a list of one-dimensional vectors."""
    labels = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    dim = len(vecs)
    if dim > len(labels):
        raise ValueError("dim is too large for this einsum construction.")
    input_terms = [labels[j] for j in range(dim)]
    output_term = "".join(input_terms)
    einsum_str = ",".join(input_terms) + "->" + output_term
    return np.einsum(einsum_str, *vecs, optimize=True)


def add_uniform_mixture_to_core(core, mat_list, constant_coeff, eta):
    """Mix current Tucker density with a projected uniform density."""
    eta = float(eta)
    if eta <= 0.0:
        return core
    if eta >= 1.0:
        raise ValueError("uniform_mixture must be smaller than 1.")

    uniform_vecs = [np.asarray(constant_coeff, dtype=float) @ Uj for Uj in mat_list]
    uniform_core = outer_from_vectors(uniform_vecs)
    return (1.0 - eta) * core + eta * uniform_core


# -----------------------------------------------------------------------------
# Implicit HOSVD initialization and HOOI updates
# -----------------------------------------------------------------------------


def implicit_mode_gram(
    basis_mat,
    mode,
    mat_list=None,
    max_pairwise_memory_gb=8.0,
):
    """Compute the small mode Gram matrix without building the full tensor.

    Let
        A = (1/N) sum_l B_1[l] otimes ... otimes B_d[l].

    If mat_list is None, this computes A_(mode) A_(mode)^T.
    If mat_list is given, this computes the HOOI update Gram after projecting
    all other modes onto their current Tucker factors.
    """
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)
    _pairwise_memory_check(N, max_pairwise_memory_gb)

    if mode < 0 or mode >= dim:
        raise ValueError("mode is out of range.")
    if mat_list is not None and len(mat_list) != dim:
        raise ValueError("mat_list must have length dim.")

    W = np.ones((N, N), dtype=float)

    for j in range(dim):
        if j == mode:
            continue
        Cj = basis_mat[j] if mat_list is None else basis_mat[j] @ mat_list[j]
        W *= Cj @ Cj.T

    Bk = basis_mat[mode]
    G = Bk.T @ (W @ Bk)
    G /= float(N * N)
    return 0.5 * (G + G.T)


def implicit_mode_gram_from_products(basis_mat, mode, pair_products):
    """Compute mode Gram using precomputed pair products P_j = C_j C_j^T."""
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)
    if len(pair_products) != dim:
        raise ValueError("pair_products must have length dim.")

    W = np.ones((N, N), dtype=float)
    for j in range(dim):
        if j != mode:
            W *= pair_products[j]

    Bk = basis_mat[mode]
    G = Bk.T @ (W @ Bk)
    G /= float(N * N)
    return 0.5 * (G + G.T)


def implicit_hosvd_initialization(
    basis_mat,
    threshold=0.9999,
    rank_rule="energy",
    min_rank=1,
    ranks=None,
    verbose=True,
    max_pairwise_memory_gb=8.0,
    cache_pairwise_products=False,
):
    """Initialize Tucker factors using implicit HOSVD."""
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)

    if ranks is not None:
        if len(ranks) != dim:
            raise ValueError("ranks must have length dim.")
        ranks = [int(r) for r in ranks]
        for r in ranks:
            if r < 1 or r > n:
                raise ValueError("Each rank must be between 1 and n.")

    pair_products = None
    if cache_pairwise_products:
        _pairwise_memory_check(N, max_pairwise_memory_gb)
        pair_products = [Bj @ Bj.T for Bj in basis_mat]

    mat_list = []
    rank_list = []
    singular_values_list = []

    for mode in range(dim):
        if cache_pairwise_products:
            G = implicit_mode_gram_from_products(basis_mat, mode, pair_products)
        else:
            G = implicit_mode_gram(
                basis_mat,
                mode,
                mat_list=None,
                max_pairwise_memory_gb=max_pairwise_memory_gb,
            )

        eigvals, eigvecs = _descending_eigh(G)
        singular_values = np.sqrt(np.maximum(eigvals, 0.0))

        if ranks is None:
            rank_k = choose_rank_from_singular_values(
                singular_values,
                threshold=threshold,
                rank_rule=rank_rule,
                min_rank=min_rank,
            )
        else:
            rank_k = ranks[mode]

        Uk = eigvecs[:, :rank_k]
        mat_list.append(Uk)
        rank_list.append(rank_k)
        singular_values_list.append(singular_values)

        if verbose:
            print(f"initial mode {mode}: singular values = {singular_values}")
            print(f"initial mode {mode}: rank = {rank_k}")

    return mat_list, rank_list, singular_values_list


def projected_norm_sq(basis_mat, mat_list, max_pairwise_memory_gb=8.0):
    """Compute || A x_1 U_1^T ... x_d U_d^T ||_F^2 implicitly."""
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)
    _pairwise_memory_check(N, max_pairwise_memory_gb)

    if len(mat_list) != dim:
        raise ValueError("mat_list must have length dim.")

    W = np.ones((N, N), dtype=float)
    for j in range(dim):
        Cj = basis_mat[j] @ mat_list[j]
        W *= Cj @ Cj.T

    val = np.sum(W) / float(N * N)
    return float(max(val, 0.0))


def build_core_from_factors(basis_mat, mat_list, max_core_memory_gb=8.0):
    """Build the Tucker core from the projected basis matrices."""
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)

    if len(mat_list) != dim:
        raise ValueError("mat_list must have length dim.")

    projected = []
    ranks = []
    for j in range(dim):
        Cj = basis_mat[j] @ mat_list[j]
        projected.append(Cj)
        ranks.append(Cj.shape[1])

    memory_gb = estimate_tensor_memory_gb(ranks)
    if memory_gb > max_core_memory_gb:
        raise MemoryError(
            f"The Tucker core has shape {tuple(ranks)} and needs about "
            f"{memory_gb:.2f} GB, exceeding max_core_memory_gb={max_core_memory_gb}."
        )

    rank_labels = "abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY"
    if dim > len(rank_labels):
        raise ValueError("dim is too large for this einsum construction.")

    input_terms = ["z" + rank_labels[j] for j in range(dim)]
    output_term = "".join(rank_labels[j] for j in range(dim))
    einsum_str = ",".join(input_terms) + "->" + output_term

    return np.einsum(einsum_str, *projected, optimize=True) / float(N)


def implicit_hooi(
    basis_mat,
    threshold=0.9999,
    rank_rule="energy",
    ranks=None,
    min_rank=1,
    max_iterate=10,
    tol=1e-8,
    verbose=True,
    max_pairwise_memory_gb=8.0,
    cache_pairwise_products=False,
):
    """HOOI for A = N^{-1} sum_l B_1[l] otimes ... otimes B_d[l]."""
    basis_mat, N, n, dim = _validate_basis_mat(basis_mat)

    mat_list, rank_list, init_singular_values_list = implicit_hosvd_initialization(
        basis_mat,
        threshold=threshold,
        rank_rule=rank_rule,
        min_rank=min_rank,
        ranks=ranks,
        verbose=verbose,
        max_pairwise_memory_gb=max_pairwise_memory_gb,
        cache_pairwise_products=cache_pairwise_products,
    )

    max_iterate = int(max_iterate)
    if max_iterate < 0:
        raise ValueError("max_iterate must be nonnegative.")

    history = []
    prev_obj = projected_norm_sq(
        basis_mat,
        mat_list,
        max_pairwise_memory_gb=max_pairwise_memory_gb,
    )
    history.append(prev_obj)

    if verbose:
        print(f"HOOI initial projected norm^2 = {prev_obj:.12e}")

    singular_values_list = init_singular_values_list

    pair_products = None
    if cache_pairwise_products:
        _pairwise_memory_check(N, max_pairwise_memory_gb)
        pair_products = []
        for j in range(dim):
            Cj = basis_mat[j] @ mat_list[j]
            pair_products.append(Cj @ Cj.T)

    for it in range(max_iterate):
        singular_values_list = []

        for mode in range(dim):
            if cache_pairwise_products:
                G = implicit_mode_gram_from_products(basis_mat, mode, pair_products)
            else:
                G = implicit_mode_gram(
                    basis_mat,
                    mode,
                    mat_list=mat_list,
                    max_pairwise_memory_gb=max_pairwise_memory_gb,
                )

            eigvals, eigvecs = _descending_eigh(G)
            singular_values = np.sqrt(np.maximum(eigvals, 0.0))
            singular_values_list.append(singular_values)

            rank_k = rank_list[mode]
            mat_list[mode] = eigvecs[:, :rank_k]

            if cache_pairwise_products:
                Ck = basis_mat[mode] @ mat_list[mode]
                pair_products[mode] = Ck @ Ck.T

        obj = projected_norm_sq(
            basis_mat,
            mat_list,
            max_pairwise_memory_gb=max_pairwise_memory_gb,
        )
        history.append(obj)

        rel_change = abs(obj - prev_obj) / max(abs(prev_obj), 1e-14)

        if verbose:
            print(
                f"HOOI iter {it + 1}: projected norm^2 = {obj:.12e}, "
                f"relative change = {rel_change:.3e}"
            )

        if rel_change < tol:
            if verbose:
                print(f"HOOI converged at iteration {it + 1}.")
            break

        prev_obj = obj

    return mat_list, rank_list, singular_values_list, history


# -----------------------------------------------------------------------------
# Prediction
# -----------------------------------------------------------------------------


class Tucker_prediction:
    """Vectorized Tucker prediction."""

    def predict(self, dim, core, mat_list, mat_test):
        if mat_test.ndim != 3:
            raise ValueError("mat_test must have shape (N_test, dim, n).")
        if mat_test.shape[1] != dim:
            raise ValueError("mat_test.shape[1] must equal dim.")
        if len(mat_list) != dim:
            raise ValueError("mat_list must have length dim.")

        W_list = [mat_test[:, j, :] @ mat_list[j] for j in range(dim)]

        sample_label = "z"
        rank_labels = "abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY"
        if dim > len(rank_labels):
            raise ValueError("dim is too large for this einsum construction.")

        core_term = "".join(rank_labels[j] for j in range(dim))
        input_terms = [core_term]
        for j in range(dim):
            input_terms.append(sample_label + rank_labels[j])

        einsum_str = ",".join(input_terms) + "->" + sample_label
        return np.einsum(einsum_str, core, *W_list, optimize=True)


# -----------------------------------------------------------------------------
# Estimator class
# -----------------------------------------------------------------------------


class Tucker:
    """Tucker density estimator using implicit HOOI.

    Parameters
    ----------
    n : int
        Number of basis functions per coordinate.
    X_train : ndarray, shape (N, dim)
        Training data.
    max_iterate : int
        Number of HOOI sweeps. Use 0 for implicit HOSVD only.
    threshold : float or int
        Rank threshold. If rank_rule='fixed', this is the common fixed rank.
    rank_rule : str
        One of 'energy', 'relative', 'absolute', 'eigen_absolute', or 'fixed'.
    ranks : list of int or None
        Optional mode-specific ranks.
    uniform_mixture : float
        Optional small mixture with uniform density in the current Tucker space.
        A value like 1e-3 may help positivity and sampling.
    """

    def __init__(
        self,
        n,
        X_train,
        max_iterate=10,
        threshold=0.9999,
        rank_rule="energy",
        ranks=None,
        min_rank=1,
        tol=1e-8,
        max_core_memory_gb=8.0,
        max_pairwise_memory_gb=8.0,
        verbose=True,
        box_quantile_eps=1e-3,
        box_pad_fraction=0.05,
        whitening_ridge=1e-6,
        domain_clip_eps=1e-6,
        derivative_floor=1e-12,
        renormalize=True,
        uniform_mixture=0.0,
        density_floor=1e-14,
        basis_integral_quad_order=None,
        sampling_max_tries=1000,
        cache_pairwise_products=False,
        max_memory_gb=None,  # compatibility with previous code
    ):
        self.n = int(n)
        self.threshold = threshold
        self.rank_rule = rank_rule
        self.min_rank = int(min_rank)
        self.max_iterate = int(max_iterate)
        self.tol = float(tol)
        self.verbose = bool(verbose)
        self.renormalize = bool(renormalize)
        self.uniform_mixture = float(uniform_mixture)
        self.density_floor = float(density_floor)
        self.sampling_max_tries = int(sampling_max_tries)

        X_train = np.asarray(X_train, dtype=float)
        if X_train.ndim != 2:
            raise ValueError("X_train must have shape (N, dim).")
        self.N, self.dim = X_train.shape

        self.new_domain = GaussianWhitenBoxDomain(
            self.dim,
            X_train,
            box_quantile_eps=box_quantile_eps,
            box_pad_fraction=box_pad_fraction,
            ridge=whitening_ridge,
            clip_eps=domain_clip_eps,
            derivative_floor=derivative_floor,
        )

        self.X_train_transform = self.new_domain.transform_data(X_train)
        self.X_train_transform = np.clip(self.X_train_transform, 0.0, 1.0)

        # generate_basis_mat(...).compute() is assumed to have shape (N, dim, n).
        # After transpose, self.basis_mat has shape (dim, N, n).
        self.basis_mat = generate_basis_mat(
            self.n, self.dim, 1, self.X_train_transform
        ).compute().transpose(1, 0, 2)

        # Keep training output quiet. The final Tucker ranks are printed at the end
        # when verbose=True.

        self.mat_list, self.ranks, self.singular_values_list, self.history = implicit_hooi(
            self.basis_mat,
            threshold=self.threshold,
            rank_rule=self.rank_rule,
            ranks=ranks,
            min_rank=self.min_rank,
            max_iterate=self.max_iterate,
            tol=self.tol,
            verbose=False,
            max_pairwise_memory_gb=max_pairwise_memory_gb,
            cache_pairwise_products=cache_pairwise_products,
        )

        self.core = build_core_from_factors(
            self.basis_mat,
            self.mat_list,
            max_core_memory_gb=max_core_memory_gb,
        )

        self.polynomial = polynomial(self.n, 1)
        self.basis_integral = compute_basis_integral(
            self.polynomial,
            self.n,
            quad_order=basis_integral_quad_order,
        )
        self.constant_coeff = compute_constant_coeff(
            self.polynomial,
            self.n,
            quad_order=basis_integral_quad_order,
        )

        if self.uniform_mixture > 0.0:
            self.core = add_uniform_mixture_to_core(
                self.core,
                self.mat_list,
                self.constant_coeff,
                self.uniform_mixture,
            )

        self.core_mass_before_normalization = projected_core_mass(
            self.core,
            self.mat_list,
            self.basis_integral,
        )

        if self.renormalize:
            self.core, _ = renormalize_core(
                self.core,
                self.mat_list,
                self.basis_integral,
            )
            self.core_mass_after_normalization = projected_core_mass(
                self.core,
                self.mat_list,
                self.basis_integral,
            )
        else:
            self.core_mass_after_normalization = self.core_mass_before_normalization

        self.mass_vectors = [self.basis_integral @ Uj for Uj in self.mat_list]
        self.sampler = Legendre_Sampler(self.n, self.polynomial.Linvt)

        if self.verbose:
            print("Final Tucker ranks:", self.ranks)

    def predict_transformed_space(self, X_test):
        """Evaluate fitted density in transformed [0,1]^d space."""
        X_test = np.asarray(X_test, dtype=float)
        if X_test.ndim != 2:
            raise ValueError("X_test must have shape (N_test, dim).")
        if X_test.shape[1] != self.dim:
            raise ValueError("X_test.shape[1] must equal dim.")

        X_test_transform = self.new_domain.transform_data(X_test)
        X_test_transform = np.clip(X_test_transform, 0.0, 1.0)

        mat_test = generate_basis_mat(
            self.n, self.dim, 1, X_test_transform
        ).compute()

        y_pred = Tucker_prediction().predict(
            self.dim,
            self.core,
            self.mat_list,
            mat_test,
        )
        return np.maximum(y_pred, self.density_floor)

    # Alias kept for compatibility with earlier version.
    def predict_pit_space(self, X_test):
        return self.predict_transformed_space(X_test)

    def predict(self, X_test):
        """Evaluate fitted density at original data-space test points."""
        X_test = np.asarray(X_test, dtype=float)
        y_pred_u = self.predict_transformed_space(X_test)
        y_pred_x = self.new_domain.transform_density_val(
            y_pred_u,
            X_test_data_space=X_test,
        )
        return np.maximum(y_pred_x, self.density_floor)

    def sample_one(self):
        """Draw one sample in transformed [0,1]^d scale."""
        result = np.zeros(self.dim)
        condition_mat = self.core

        for d in range(self.dim - 1):
            tail_vec = self.compute_marginal(condition_mat, first_mode=d)
            cur_vec = self.mat_list[d] @ tail_vec

            result[d] = self.sampler.sample(cur_vec)
            if result[d] == -np.inf or not np.isfinite(result[d]):
                return False, []

            cur_basis_val = self.polynomial.scalar_all_basis_alpha(result[d])
            cur_basis_val_r = cur_basis_val @ self.mat_list[d]

            condition_mat = np.tensordot(
                condition_mat,
                cur_basis_val_r,
                axes=([0], [0]),
            )

        cur_vec = self.mat_list[-1] @ condition_mat
        result[-1] = self.sampler.sample(cur_vec)
        if result[-1] == -np.inf or not np.isfinite(result[-1]):
            return False, []

        return True, result

    def sample(self, N_sample, verbose=True):
        """Draw samples from the fitted Tucker density on original data scale."""
        N_sample = int(N_sample)
        result = np.zeros((N_sample, self.dim))

        for i in range(N_sample):
            if verbose and i % 1000 == 0:
                print(i)

            ok = False
            sample_point = None
            for _ in range(self.sampling_max_tries):
                ok, sample_point = self.sample_one()
                if ok:
                    break

            if not ok:
                raise RuntimeError(
                    "Sampling failed too many times. Try larger ranks, "
                    "uniform_mixture=1e-3, or a larger box_pad_fraction."
                )

            result[i] = sample_point

        return self.new_domain.inverse_compute_data(result)

    def compute_marginal(self, cur_tensor, first_mode):
        """Compute marginal vector needed for sequential conditional sampling."""
        temp_tensor = cur_tensor
        for mode in range(self.dim - 1, first_mode, -1):
            temp_tensor = np.tensordot(
                temp_tensor,
                self.mass_vectors[mode],
                axes=([-1], [0]),
            )
        return temp_tensor


if __name__ == "__main__":
    rng = np.random.default_rng(123)

    N = 5400
    dim = 6
    basis_n = 30

    # Example with rotated Gaussian data.
    A = rng.normal(size=(dim, dim))
    X_train = rng.normal(size=(N, dim)) @ A.T

    model = Tucker(
        n=basis_n,
        X_train=X_train,
        max_iterate=3,
        threshold=8,
        rank_rule="fixed",
        uniform_mixture=1e-3,
        box_quantile_eps=1e-3,
        box_pad_fraction=0.05,
        verbose=True,
        cache_pairwise_products=False,
    )

    X_test = rng.normal(size=(10, dim)) @ A.T
    y_pred = model.predict(X_test)

    print("Prediction shape:", y_pred.shape)
    print("Predictions:", y_pred)

    X_samp = model.sample(5, verbose=False)
    print("Samples shape:", X_samp.shape)
    print(X_samp)
