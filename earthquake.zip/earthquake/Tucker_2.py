import numpy as np
from scipy.linalg import eigh
from local_basis import generate_basis_mat, polynomial
from sampling_local import Legendre_Sampler

# Make sure domain is imported from your own file.


class SuffixMatrixBuilder:
    """
    Build the full suffix matrix

        K_suffix[i, l] = product_{j=1}^{dim-1} <B_j[i, :], B_j[l, :]>.
    """
    def __init__(self, dim):
        self.dim = dim

    def compute(self, basis_mat):
        if self.dim < 2:
            raise ValueError("This version assumes dim >= 2.")

        suffix_mat = basis_mat[self.dim - 1] @ basis_mat[self.dim - 1].T

        for j in range(self.dim - 2, 0, -1):
            suffix_mat *= (basis_mat[j] @ basis_mat[j].T)

        return suffix_mat


class ModeFactorEstimator:
    """
    Exact computation of G_cur for coordinate k by reordering basis_mat
    so that coordinate k becomes the first coordinate.
    """
    def __init__(self, N, dim, n, basis_mat, k, threshold=100):
        self.N = N
        self.dim = dim
        self.n = n
        self.k = k
        self.threshold = threshold

        order = [k] + [j for j in range(dim) if j != k]
        self.basis_mat = [np.asarray(basis_mat[j]) for j in order]

        self.suffix_mat = SuffixMatrixBuilder(dim).compute(self.basis_mat)

    def compute(self):
        """
        Compute thresholded G_cur for the original coordinate k.
        Remove eigenvectors associated with small singular values.
        """
        B0 = self.basis_mat[0]
    
        target_mat = B0.T @ self.suffix_mat @ B0
        target_mat = 0.5 * (target_mat + target_mat.T)
    
        values, G_cur = eigh(target_mat, check_finite=False)
    
        idx = np.argsort(values)[::-1]
        values = values[idx]
        #print(values)
        G_cur = G_cur[:, idx]
    
        svals = np.abs(values)
        keep = svals >= self.threshold
    
        rank_k = np.sum(keep)
        G_cur = G_cur[:, keep]
    
        return rank_k, G_cur


class Tucker:
    def __init__(self, n, X_train, max_iterate, threshold=0.9999):
        self.n = n
        self.threshold = threshold

        self.N, self.dim = X_train.shape

        self.new_domain = domain(self.dim, X_train)
        self.X_train_transform = self.new_domain.transform_data(X_train)
        self.X_train_transform = np.clip(self.X_train_transform, 0, 1)

        self.basis_mat = generate_basis_mat(
            n, self.dim, 1, self.X_train_transform
        ).compute().transpose(1, 0, 2)

        self.mat_list = []
        self.ranks = []

        for k in range(self.dim):
            rank_k, G_cur = ModeFactorEstimator(
                self.N, self.dim, self.n, self.basis_mat, k, self.threshold
            ).compute()
            self.mat_list.append(G_cur)
            self.ranks.append(rank_k)

        print(self.ranks)

        self.polynomial = polynomial(n, 1)
        self.sampler = Legendre_Sampler(n, self.polynomial.Linvt)

        for _ in range(max_iterate):
            self.iterate()
            print(self.ranks)

        self.compute_core()

    def compute_core(self):
        projected_basis = [
            self.basis_mat[j] @ self.mat_list[j] for j in range(self.dim)
        ]

        rank_labels = "abcdefghijklmopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if self.dim > len(rank_labels):
            raise ValueError("dim is too large for this einsum construction.")

        input_terms = [f"n{rank_labels[j]}" for j in range(self.dim)]
        output_term = "".join(rank_labels[j] for j in range(self.dim))
        einsum_str = ",".join(input_terms) + "->" + output_term

        self.core = np.einsum(einsum_str, *projected_basis) / self.N

    def iterate(self):
        """
        One refinement sweep:
        project every mode by its current factor,
        then update each coordinate while keeping that coordinate
        in the original n-dimensional basis.
        """
        projected_basis = [
            self.basis_mat[k] @ self.mat_list[k] for k in range(self.dim)
        ]

        new_mat_list = []
        new_ranks = []

        for mode in range(self.dim):
            current_basis = projected_basis.copy()
            current_basis[mode] = self.basis_mat[mode]

            rank_k, G_cur = ModeFactorEstimator(
                self.N, self.dim, self.n, current_basis, mode, self.threshold
            ).compute()

            new_mat_list.append(G_cur)
            new_ranks.append(rank_k)

        self.mat_list = new_mat_list
        self.ranks = new_ranks
        
    def predict(self, X_test):
        X_test_transform = self.new_domain.transform_data(X_test)
        X_test_transform = np.clip(X_test_transform, 0, 1)

        mat_test = generate_basis_mat(
            self.n, self.dim, 1, X_test_transform
        ).compute()

        y_pred = Tucker_prediction().predict(
            self.dim, self.core, self.mat_list, mat_test
        )
        y_pred = self.new_domain.transform_density_val(y_pred)

        return np.clip(y_pred, 1e-14, np.inf)

    def sample_one(self):
        result = np.zeros(self.dim)
        condition_mat = self.core

        for d in range(self.dim - 1):
            tail_vec = self.compute_marginal(condition_mat, first_mode=d)
            cur_vec = self.mat_list[d] @ tail_vec

            result[d] = self.sampler.sample(cur_vec)
            if result[d] == -np.inf:
                return False, []

            cur_basis_val = self.polynomial.scalar_all_basis_alpha(result[d])
            cur_basis_val_r = cur_basis_val @ self.mat_list[d]

            condition_mat = np.tensordot(
                condition_mat,
                cur_basis_val_r,
                axes=([0], [0])
            )

        cur_vec = self.mat_list[-1] @ condition_mat
        result[-1] = self.sampler.sample(cur_vec)
        if result[-1] == -np.inf:
            return False, []

        return True, result

    def sample(self, N_sample):
        result = np.zeros((N_sample, self.dim))

        for i in range(N_sample):
            if i % 1000 == 0:
                print(i)

            ok, sample_point = self.sample_one()
            while not ok:
                ok, sample_point = self.sample_one()

            result[i] = sample_point

        return self.new_domain.inverse_compute_data(result)

    def compute_marginal(self, cur_tensor, first_mode):
        """
        cur_tensor has axes corresponding to original modes
            first_mode, first_mode+1, ..., self.dim-1

        Returns a vector in the rank space of original mode `first_mode`.
        """
        temp_tensor = cur_tensor

        for mode in range(self.dim - 1, first_mode, -1):
            temp_tensor = np.tensordot(
                temp_tensor,
                self.mat_list[mode][0, :],
                axes=([-1], [0])
            )

        return temp_tensor


class domain:
    def __init__(self, dim, X_train):
        factor = 10 ** (-5)
        self.X_train = X_train
        self.dim = dim

        self.upper = []
        self.lower = []
        for dd in range(dim):
            self.upper.append(np.quantile(X_train[:, dd], 1 - factor))
            self.lower.append(np.quantile(X_train[:, dd], factor))

        self.upper = np.array(self.upper)
        self.lower = np.array(self.lower)

        self.difference = self.upper - self.lower
        self.density_factor = np.prod(self.difference)

    def transform_density_val(self, val):
        return val / self.density_factor

    def transform_data(self, XX):
        X_transform = (XX - self.lower) / self.difference
        return X_transform

    def transform_partial_data(self, begin_dim, end_dim, XX):
        X_transform = (XX - self.lower[begin_dim:end_dim]) / self.difference[begin_dim:end_dim]
        return X_transform

    def inverse_compute_data(self, UU):
        UU = np.asarray(UU)
        return UU * self.difference + self.lower

    def inverse_partial_data(self, begin_dim, end_dim, UU):
        UU = np.asarray(UU)
        return UU * self.difference[begin_dim:end_dim] + self.lower[begin_dim:end_dim]


class Tucker_prediction:
    def predict(self, dim, core, mat_list, mat_test):
        """
        Vectorized prediction for all test points.

        Parameters
        ----------
        dim : int
            Number of dimensions.
        core : np.ndarray
            Tucker core of shape (ranks[0], ..., ranks[dim-1]).
        mat_list : list of np.ndarray
            mat_list[j] has shape (n, ranks[j]).
        mat_test : np.ndarray
            Shape (N_test, dim, n).

        Returns
        -------
        y_pred : np.ndarray
            Shape (N_test,).
        """
        if mat_test.ndim != 3:
            raise ValueError("mat_test must have shape (N_test, dim, n).")
        if mat_test.shape[1] != dim:
            raise ValueError("mat_test.shape[1] must equal dim.")
        if len(mat_list) != dim:
            raise ValueError("mat_list must have length dim.")

        W_list = [mat_test[:, j, :] @ mat_list[j] for j in range(dim)]

        sample_label = "t"
        rank_labels = "abcdefghijklmnopqrsuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if dim > len(rank_labels):
            raise ValueError("dim is too large for this einsum construction.")

        core_term = "".join(rank_labels[j] for j in range(dim))
        input_terms = [core_term]
        for j in range(dim):
            input_terms.append(sample_label + rank_labels[j])

        einsum_str = ",".join(input_terms) + "->" + sample_label

        y_pred = np.einsum(einsum_str, core, *W_list)
        return y_pred